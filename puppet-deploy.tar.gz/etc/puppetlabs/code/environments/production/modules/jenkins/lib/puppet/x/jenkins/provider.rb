require_relative '../jenkins'

module Puppet::X::Jenkins::Provider; end
